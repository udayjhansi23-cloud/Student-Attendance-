from fastapi import FastAPI
from fastapi.responses import HTMLResponse

app = FastAPI()


@app.get("/", response_class=HTMLResponse)
def home():
    return """
    <html>
        <head>
            <title>Student Attendance</title>
        </head>

        <body>
            <h1>Student Attendance System</h1>

            <h2>Welcome!</h2>
            <p>Our attendance project is working.</p>
        </body>
    </html>
    """