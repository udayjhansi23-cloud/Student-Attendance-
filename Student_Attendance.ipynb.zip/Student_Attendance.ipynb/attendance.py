print("===== Student Attendance System =====")

students = {}

while True:
    print("\n1. Add Student")
    print("2. Mark Attendance")
    print("3. View Attendance")
    print("4. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        name = input("Enter student name: ")
        students[name] = "Not Marked"
        print("Student added successfully!")

    elif choice == "2":
        name = input("Enter student name: ")

        if name in students:
            attendance = input("Enter P for Present or A for Absent: ")

            if attendance.upper() == "P":
                students[name] = "Present"
                print("Attendance marked as Present.")
            elif attendance.upper() == "A":
                students[name] = "Absent"
                print("Attendance marked as Absent.")
            else:
                print("Please enter only P or A.")
        else:
            print("Student not found.")

    elif choice == "3":
        print("\n===== Attendance =====")

        if len(students) == 0:
            print("No students added yet.")
        else:
            for name, attendance in students.items():
                print(name, ":", attendance)

    elif choice == "4":
        print("Thank you!")
        break

    else:
        print("Invalid choice. Please try again.")